Please download newest version of WebAPI protocols from below link:
https://partners.cqg.com/api-resources/web-api/documentation

The generater.cmd generates all _pb2.py files for all protocol files in WebAPI and common folders.

After running the generater, move the 
webapi_1_pb2.py
rules_1_pb2.py
metadata_1_pb2.py
from folder Samples\WebAPI\WebAPI to folder Samples\WebAPI 